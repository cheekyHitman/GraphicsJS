var canv2 = document.getElementById('MyCanvas2');
	console.log(canv2)
	var ctx2 = canv2.getContext('2d');

var img = ctx2.createImageData(width, height);
var buffer = new Uint8ClampedArray(width * height * 4); // have enough bytes

var z;
var pos = 0;
var x = 0;
var y = 0;
var cY = centerY;
var cX = centerX;
var shLR = 0;
var shUD = 0;

function setPixelData(R, G, B, a){
	buffer[pos] = R;             // some R value [0, 255]
    buffer[pos+1] = G;           // some G value
    buffer[pos+2] = B;           // some B value
    buffer[pos+3] = a;
    pos+=4;
}

function setPixels(f_val){

	var z = eval(f_val);
		if(z > 0){
			setPixelData(0,255/z,0,255);
		} else if(z < 0){
			setPixelData(abs(255/z),0,0,255);
		} else {
			setPixelData(0,0,200,255);
		}
}


function drawImage(f_val, step) {
	shLR += shiftLR;
	shUD += shiftUD;
	z = step;
	for(var y1 = cY; y1 > -cY; y1--) {
    	for(var x1 = -cX; x1 < cX; x1++) {
    		x = (x1 - shLR)/z;
    		y = (y1 + shUD)/z;
    		setPixels(f_val);
    	}   
	}
	// set our buffer as source
	img.data.set(buffer);
	// update canvas with new data
	ctx2.putImageData(img, 0, 0);
	pos = 0;
}

var xR = 0;
var yR = 0;

function drawRect(f_val, w1, h1){
	var z = eval(f_val);
	if(yR < height - h1){
		if(z > 0) {
			ctx2.fillRect(xR, yR, w1, h1)
			ctx2.fillStyle = "rgb(0," + 255/z + ",0)";
			ctx2.fill();
		} else if(z < 0){
			ctx2.fillRect(xR, yR, w1, h1)
			ctx2.fillStyle = "rgb(" + abs(255/z) + ",0,0)";
			ctx2.fill();
		} else {
			ctx2.fillRect(xR, yR, w1, h1)
			ctx2.fillStyle = "rgb(0,0,255)";
			ctx2.fill();
		}
		if(xR < canv2.width-w1){
			xR += w1;
		} else {
			yR += h1;
			xR = 0;
		}
	} else {
		yR = 0;
		xR = 0;
	}
}

function drawFunctionRect(f_val, step) {
	ctx2.beginPath();
	shLR += shiftLR;
	shUD += shiftUD;

	z = step;
	for(var y1 = cY; y1 > -cY; y1--) {
    	for(var x1 = -cX; x1 < cX; x1++) {
    		x = (x1 - shLR)/z;
    		y = (y1 + shUD)/z;
    		drawRect(f_val, 1,1);
    	}   
	}
	ctx2.closePath();
	ctx2.stroke();
	yR = 0;
	xR = 0;
}

function makeCenter(){
	shLR = 0;
	shUD = 0;
}