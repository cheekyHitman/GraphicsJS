
var step = 20; //
var width = 400;
var height = 400;
var startX = 0;
var startY = 0;
var centerY = height/2;
var centerX = width/2;

function cordConstructor(wid, hei) {
	width = wid;
	height = hei;
	centerY = height/2;
	centerX = width/2;
}

function DrawCordinator(shiftLR, shiftUD, _step){
	centerX += shiftLR;
	centerY += shiftUD;
	step = _step;
	
	let tShiftLR = 5;
	let tShiftUD = -3;
	
	ctx.beginPath();
	ctx.strokeStyle='white';
	ctx.lineWidth=1;
	ctx.fillStyle='white';
	for (var i = centerX; i <= width; i = i + step)
	{
		ctx.moveTo(i, startY);
		ctx.lineTo(i, height);
		ctx.fillText((i-centerX)/step, i+tShiftLR, centerY+tShiftUD);
	}
	
	for (var i = centerY; i <= height; i = i + step)
	{
		ctx.moveTo(startX, i);
		ctx.lineTo(width, i);
		if(i-centerY > 0){ ctx.fillText('-'+(i-centerY)/step, centerX+tShiftLR, i+tShiftUD); }
	}
	
	for (var i = centerX; i >= 0; i = i - step)
	{
		ctx.moveTo(i, startY);
		ctx.lineTo(i, height);
		if(i+centerX != 2*i) { ctx.fillText((i-centerX)/step, i+tShiftLR, centerY+tShiftUD); }
	}
	
	for (var i = centerY; i >= 0; i = i - step)
	{
		ctx.moveTo(startX, i);
		ctx.lineTo(width, i);
		if(i+centerY != 2*i) { ctx.fillText((-(i-centerY))/step, centerX+tShiftLR, i+tShiftUD); }
	}
	ctx.stroke();
}

function CleanCanvas(){
	ctx.clearRect(0,0,canv.width, canv.height)
}

function centration(cY1, cX1){
	centerY = cY1;
	centerX = cX1;
}

function shiftCordToFunc(c1, c2){
	centerY += c1;
	centerX += c2;
}
