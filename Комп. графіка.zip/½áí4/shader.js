var gl;
var shaderProgram;
var vertexBuffer;
// установка шейдеров
function initShaders() {
    // получаем шейдеры
    var fragmentShader = getShader(gl.FRAGMENT_SHADER, 'shader-fs');
    var vertexShader = getShader(gl.VERTEX_SHADER, 'shader-vs');
    //создаем объект программы шейдеров
    shaderProgram = gl.createProgram();
    // прикрепляем к ней шейдеры
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    // связываем программу с контекстом webgl
    gl.linkProgram(shaderProgram);
      
    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert("Не удалсь установить шейдеры");
    }      
    gl.useProgram(shaderProgram);
    // установка атрибута программы
    shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
    // делаем доступным атрибут для использования
    gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

    
}

// Функция создания шейдера по типу и id источника в структуре DOM
function getShader(type,id) {
    var source = document.getElementById(id).innerHTML;
    func = func.replace(/x/g, "coordinate.x");
    func = func.replace(/y/g, "coordinate.y");
    source = source.replace("<func>", func);
    let step_float;
    if(step >= 1){
        step_float = step + ".0"
    } else {
        step_float = step;
    }
    source = source.replace("<step>", step_float);
    let shlr = shiftLR + ".0";
    let shud = shiftUD + ".0";
    source = source.replace("<shiftLR>", shlr);
    source = source.replace("<shiftUD>", shud);
    
    console.log(source);
    // создаем шейдер по типу
    var shader = gl.createShader(type);
    // установка источника шейдера
    gl.shaderSource(shader, source);
    // компилируем шейдер
    gl.compileShader(shader);
   
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert("Ошибка компиляции шейдера: " + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);   
        return null;
    }
    return shader;  
}
// установка буфера вершин 
function initBuffers() {
 // установка буфера вершин
  vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  // массив координат вершин объекта
  var triangleVertices = [
        -1.0, 1.0,
        1.0, 1.0,
        -1.0, -1.0,
        1.0, 1.0,
        -1.0, -1.0,
        1.0, -1.0
  ];
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(triangleVertices), gl.STATIC_DRAW);
  // указываем кол-во точек
  vertexBuffer.itemSize = 2;
  vertexBuffer.numberOfItems = 6;
}

// отрисовка 
function draw() {    
    // установка области отрисовки
    //gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
 
    gl.clear(gl.COLOR_BUFFER_BIT);
   
    // указываем, что каждая вершина имеет по три координаты (x, y, z)
    gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, 
                         vertexBuffer.itemSize, gl.FLOAT, false, 0, 0);
    // отрисовка примитивов - треугольников          
    gl.drawArrays(gl.TRIANGLES, 0, vertexBuffer.numberOfItems);
}