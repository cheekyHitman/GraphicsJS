'use strict';
var canvas = document.getElementById('MyCanvas2');
var drawCanvas = document.getElementById('DrawCanvas');
 console.log(canvas)
var context = canvas.getContext('2d');
var drawCtx = drawCanvas.getContext('2d');
context.globalAlpha = 0;

canvas.width = 1200//window.screen.width
canvas.height = 800//window.screen.height
drawCanvas.width = 1200;
drawCanvas.height = 800;

var centerX = canvas.width/2;
var centerY = canvas.height/2;

var startRectCordX = centerX - 150;
var startRectCordY = centerY - 150;

var decartRectMass = [4];
var decartDiagRectMass = [2];
var rad;

let bigRect = new Path2D();
let smallrect1 = new Path2D();
let smallrect2 = new Path2D();
let lath = new Path2D();

//try 
var decSmall1;
var decSmall2;
//end

function DrawRoundRectandleWithShadow(x,y, height, width, radius) {

	context.strokeStyle = "blue";
	context.lineWidth = 20;
	context.lineCap = "square";
	context.shadowOffsetX = 3;
	context.shadowOffsetY = 3; 
	context.shadowBlur = 5;
	context.shadowColor = "black";

	rad = radius/2;
	//bigRect.beginPath();
	bigRect.moveTo(x+radius, y);
	decartRectMass[0] = new DecartCord(x,y);

	bigRect.lineTo(x + width - radius, y);
	decartRectMass[1] = new DecartCord(x + width, y);

	bigRect.arcTo(x + width, y, x + width, y + radius, radius);
	bigRect.lineTo(x + width, y + height - radius);
	decartRectMass[2] = new DecartCord(x + width, y + height);

	bigRect.arcTo(x + width, y + height, x + width-radius, y + height, radius);
	bigRect.lineTo(x + radius, y + width);
	decartRectMass[3] = new DecartCord(x,y+width);

	bigRect.arcTo(x, y + width, x, y + width - radius, radius);
	bigRect.lineTo(x, y+radius);
	bigRect.arcTo(x, y, x+radius, y, radius);
	drawDiagonalRect();
	context.fillStyle = 'blue';
	context.fill(bigRect);
	context.stroke(bigRect);
}

function drawDiagonalRect(){
	var shift = 10;
	var width = 4;
	bigRect.moveTo(decartRectMass[0].getX()+shift, decartRectMass[0].getY()+rad+shift+width);
	bigRect.lineTo(decartRectMass[0].getX()+rad+shift+width, decartRectMass[0].getY()+shift);
	bigRect.lineTo(decartRectMass[2].getX()-shift, decartRectMass[2].getY()-rad-shift-width);
	bigRect.lineTo(decartRectMass[2].getX()- rad-shift-width, decartRectMass[2].getY()-shift);
	bigRect.lineTo(decartRectMass[0].getX()+shift, decartRectMass[0].getY()+rad+shift+width);

	bigRect.moveTo(decartRectMass[1].getX()-rad-shift-width, decartRectMass[1].getY()+shift);
	bigRect.lineTo(decartRectMass[1].getX()-shift, decartRectMass[1].getY()+rad+shift+width);
	bigRect.lineTo(decartRectMass[3].getX()+rad+shift+width, decartRectMass[3].getY()-shift);
	bigRect.lineTo(decartRectMass[3].getX()+shift, decartRectMass[3].getY()-rad-shift-width);
	bigRect.lineTo(decartRectMass[1].getX()-rad-shift-width, decartRectMass[1].getY()+shift);
}


function drawFirstSmallRect(shiftX, rad1, xx) {
	context.strokeStyle = "green";
	context.lineWidth = 4;

	if(decartRectMass[0].getX()+shiftX+xx > decartRectMass[0].getX() && decartRectMass[0].getX()+xx+shiftX < decartRectMass[2].getX()) {
		var x = decartRectMass[2].getX() - shiftX - xx;
	} else if(decartRectMass[0].getX() + xx <= decartRectMass[0].getX()) {
		var x = decartRectMass[0].getX() + shiftX;
	} else if(decartRectMass[0].getX()+xx >= decartRectMass[2].getX()) {
		var x = decartRectMass[2].getX() - shiftX;
	}
	
	var y = LineTwoPoint1(x, decartRectMass[0], decartRectMass[2]);
	drawSmallRect(smallrect1, x, y, rad1);

	//try
	decSmall1 = new DecartCord(x,y); //end

	context.fillStyle = 'green';
	context.fill(smallrect1);
	context.stroke(smallrect1);
}

function drawSecondSmallRect(shiftX, rad1, xx) {
	var x;
	context.strokeStyle = "green";
	context.lineWidth = 4;
	
	if(decartRectMass[3].getX()+shiftX + xx > decartRectMass[3].getX() && decartRectMass[3].getX() + shiftX + xx < decartRectMass[1].getX()) {
		x = decartRectMass[3].getX() + shiftX + xx;
	} else if(decartRectMass[3].getX() + xx <= decartRectMass[1].getX()){
		x = decartRectMass[3].getX() - shiftX;
	} else if(decartRectMass[3].getX()+xx >= decartRectMass[3].getX){
		x = decartRectMass[3].getX() + shiftX;
	}
		
	var y = LineTwoPoint1(x, decartRectMass[1], decartRectMass[3]);
	drawSmallRect(smallrect2, x, y, rad1);
	//try 
	decSmall2 = new DecartCord(x,y); //end

	context.fillStyle = 'green';
	context.fill(smallrect2);
	context.stroke(smallrect2);
}

var radDes; 

function drawSmallRect(path2, x, y, radDesCirc) {
	path2.moveTo(x, y + radDesCirc);
	path2.lineTo(x + radDesCirc, y);
	path2.lineTo(x, y - radDesCirc);
	path2.lineTo(x - radDesCirc, y);
	path2.lineTo(x, y + radDesCirc);
	radDes = radDesCirc;
}

var DRAW = false;
var lastFrame = false;

function drawRotatedLath(length){
	context.beginPath();
	
	context.strokeStyle = "blue";
	context.lineWidth = 4;
	//console.log("decSmall2" + decSmall2);
	let td = 0;
		let deg = drawMainLath(lath, decSmall1, decSmall2, length, 14, 7);
		context.translate(decSmall2.getX(), decSmall2.getY());
		if(decSmall1.getX()<=decSmall2.getX()){
			context.rotate(deg + Math.PI);
			td = deg + Math.PI;
		} else {
			context.rotate(Math.PI - deg);
			td = Math.PI - deg;
		}

		let tPenX = decSmall2.getX() + (decCordPen.getY()) * Math.sin(-td);
		let tPenY = decSmall2.getY() + (decCordPen.getY()) * Math.cos(-td);
		
			decCordPen = new DecartCord(tPenX, tPenY);
		if(!DRAW){
			drawCtx.beginPath();
			drawCtx.strokeStyle = "red";
			drawCtx.lineWidth = 4;
			drawCtx.moveTo(tPenX, tPenY);
			DRAW = true;
			lastFrame = false;
		} else {	
			drawCtx.lineTo(tPenX, tPenY);
			drawCtx.stroke();
		}
	if(lastFrame == true){
		drawCtx.closePath();
		DRAW = false;
	}

	context.fillStyle = "transparent";
	context.fill(lath);
	context.stroke(lath);
	context.closePath();
	//console.log("after transform  decCordPen = " + decCordPen.toString());
	context.rotate(-td);
	context.translate(-decSmall2.getX(), -decSmall2.getY());
}

var decCordPen;

function drawMainLath(path, dec1, dec2, hh, ww, rr) {
	path.moveTo(ww,ww);
	path.lineTo(ww,-hh + ww);
	path.lineTo(- ww, - hh + ww);
	path.lineTo(- ww, + ww);
	path.lineTo( ww, ww);

	let vec1 = new DecartCord(0, hh);
	let vec2 = new DecartCord(dec1.getX() - dec2.getX(), dec1.getY() - dec2.getY());
	let v1v2 = vec1.getY()*vec2.getY(); //vec1.getX()*vec2.getX()
	let v1 = vec1.getY();
	let v2 = Math.sqrt(vec2.getX()**2 + vec2.getY()**2);
	let cosL = v1v2/(v1*v2);
	//console.log("cos L = " + cosL);

	path.moveTo(rr, 0);
	path.arc(0, 0, rr, 0, 2*Math.PI, false);

	path.moveTo(rr, -fixDistance);
	path.arc(0, -fixDistance, rr, 0, 2*Math.PI, false);

	decCordPen = new DecartCord(0, -hh+4*rr);
	path.moveTo(rr, -hh + 4*rr);
	path.arc(decCordPen.getX(), decCordPen.getY(), rr, 0, 2*Math.PI, false);
	//console.log("decCordPen = " + decCordPen);
	return Math.acos(cosL);
}

function LineTwoPoint1(x, dec1, dec2){
	var y = ((x-dec1.getX())*(dec2.getY()-dec1.getY()))/(dec2.getX()-dec1.getX())+dec1.getY();
	return y;
}

function clearCanvas2() {
	bigRect = new Path2D();
	smallrect1 = new Path2D();
	smallrect2 = new Path2D();
	lath = new Path2D();
	context.clearRect(0,0,canvas.width, canvas.height)
}

function ClearDrawCanvas(){
	drawCtx.closePath();
	DRAW = false;
	drawCtx.clearRect(0,0,drawCanvas.width, drawCanvas.height);			
}

function DistanseBetwenTwoPoint(dec1, dec2) {
	return Math.sqrt((dec2.getX() - dec1.getX())**2 + (dec2.getY() - dec1.getY())**2);
}

function centerCordinate(){
	return new DecartCord((decartRectMass[0].getX()+decartRectMass[2].getX())/2,
		(decartRectMass[0].getY()+decartRectMass[2].getY())/2);
}

var fixDistance;
var maxDistanse;
var startDrawing = false;
var centerCord;
var decSmall1_relCenter;
var decSmall2_relCenter;
var startX;


//btnFix onClick()
function FixValue() {
	fixDistance = DistanseBetwenTwoPoint(decSmall1, decSmall2);
	console.log("fixDistance = " + fixDistance);
	console.log("decSmall1" + decSmall1);
	console.log("decSmall2" + decSmall2);
	startX = decSmall2.getX();
	maxDistanse = DistanseBetwenTwoPoint(decartRectMass[0], decartRectMass[2])/2;
	console.log("maxDistanse = " + maxDistanse);
	centerCord = centerCordinate();
	findDecS2rC()

	console.log("centerCord = " + centerCord);

	if(fixDistance<= maxDistanse){
		startDrawing = true;
	} else {
		startDrawing = false;
		alert("Error, fixDistance > maxDistanse!!!");
	}
}

function findDecS2rC(){
	decSmall2_relCenter = new DecartCord(decSmall2.getX() - centerCord.getX(),
			 decSmall2.getY() - centerCord.getY());
}

function motionPhysics() {
	findDecS2rC();
	let tX1 = Math.sqrt(((fixDistance**2)/2) - decSmall2_relCenter.getX()**2);
	if(decSmall2_relCenter.getX() > 0) {
		if(motionDirection == "left") {
			decSmall1_relCenter = new DecartCord(tX1, -tX1);
		} else if(motionDirection == "right") {
			decSmall1_relCenter = new DecartCord(-tX1, tX1);
		}

	} else {
		console.log("else");
		if(motionDirection == "left") {
			decSmall1_relCenter = new DecartCord(tX1, -tX1);
		} else if(motionDirection == "right") {
			decSmall1_relCenter = new DecartCord(-tX1, tX1);
		}
	}
}

function drawFSR(x1, y1, rad1) {
	context.strokeStyle = "green";
	context.lineWidth = 4;

	//let y1;
	//y1 = LineTwoPoint1(x1, decartRectMass[0], decartRectMass[2]);
	drawSmallRect(smallrect1, x1, y1, rad1);

	//try
	decSmall1 = new DecartCord(x1,y1); //end
	context.fillStyle = 'green';
	context.fill(smallrect1);
	context.stroke(smallrect1);
	return y1;
}

var endAnimte1X;
var passed_time;
var Dur;
var motionDirection;

function drawRequestFrame(step) {
	clearCanvas2();
	DrawRoundRectandleWithShadow(startRectCordX, startRectCordY ,300, 300, 30);
	drawSecondSmallRect(30, 15, shiftSecondRect+step);
	motionPhysics();

	let tX1;
	let tY1;
	tX1 = centerCord.getX() - decSmall1_relCenter.getX();
	tY1 = centerCord.getY() + decSmall1_relCenter.getY();

	/*if(motionDirection == "left"){
		//console.log("decSmall2_rC = "+decSmall1_relCenter.getX());
		
		console.log( "value < " + tX1);
	} else if(decSmall1_relCenter.getX() <= 0 && motionDirection == "right") {
		tX1 = centerCord.getX() - decSmall1_relCenter.getX();
		tY1 = centerCord.getY() + decSmall1_relCenter.getY();
		console.log( "value >= " + tX1);
	}*/
	drawFSR(tX1, tY1, 15);
	
	decSmall1 = new DecartCord(tX1, tY1);
	drawRotatedLath(450);
}
var tx; //tempMaxDistanse relation to center;
var txX;

function animate(draw, duration) {
	if(!startDrawing){
		return;
	}
	console.log("shifth secondRect = " + shiftSecondRect);
	Dur = duration;
	tx = fixDistance/Math.sqrt(2);

	var start = performance.now();
	let temp;
	let frame_time;
	let middle = false;
	motionDirection = "right";
	txX = centerCord.getX() + tx;
	//let tSmall2X = decSmall2.getX();
	temp = (centerCord.getX() + tx) - decSmall2.getX();
	let shortage = tx - (centerCord.getX() - decSmall2.getX());
	console.log("shortage = " + shortage);
	console.log("temp = " + temp);
  	frame_time = temp/(duration/2);

  	requestAnimationFrame(function animate(time) {
	    // определить, сколько прошло времени с начала анимации
	    var timePassed = time - start;
	    passed_time = timePassed;

	    
	    if(timePassed > duration/2 && middle == false) {
	    	//temp += shortage;
	    	//frame_time = temp/duration/2;
	    	motionDirection = "left";
	    	console.log("frame_time = " + frame_time);
	    	middle = true;
	    }

	    // возможно небольшое превышение времени, в этом случае зафиксировать конец
	    if (timePassed > duration) {
	    	timePassed = duration;
	    	lastFrame = true;
	    }
	    // нарисовать состояние анимации в момент timePassed
	    if(timePassed <= duration/2){
	    	draw(timePassed*frame_time);
	    } else {
	    	draw((duration-timePassed)*frame_time);
	    }
	    
	    let f = DistanseBetwenTwoPoint(decSmall2, decSmall1);
	    	console.log("endDistanse = " + f );
	    // если время анимации не закончилось - запланировать ещё кадр
	    if (timePassed < duration) {
	      requestAnimationFrame(animate);
	    }
  	});
}


function AnimateFrames(){
	animate(function(timePassed) {
        drawRequestFrame(timePassed);
      }, 4000);
}

function UnFix() {
	startShiftSmallRect_1_2 = false;
	startShiftSmallRect_2_1 = false;
	startDrawing = false;
}

let downX;
let downY;
let startRemove = false;

let startShiftSmallRect = false;
let startShiftSmallRect2 = false;

let startShiftSmallRect_1_2 = false;
let startShiftSmallRect_2_1 = false;

let shiftFirstRect = 0;
let shiftSecondRect = 0;

let shiftLath = false;

canvas.onmousedown = function(e) {
	if (e.which != 1) { // если клик правой кнопкой мыши
  		return; // то он не запускает перенос
	}
	
	if(context.isPointInPath(lath, e.pageX, e.pageY)) {
		console.log(lath);
		shiftLath = true;
	} else if (context.isPointInPath(smallrect2, e.pageX, e.pageY)){
		if(startDrawing == true){
			startShiftSmallRect_2_1 = true;
		} else {
			startShiftSmallRect2 = true;
			
		}
	} else if(context.isPointInPath(smallrect1, e.pageX, e.pageY)) {
		if(startDrawing == true) {
			startShiftSmallRect_1_2 = true;
		} else {
			startShiftSmallRect = true;
			//downX = e.pageX;
			//downY = e.pageY;
		}
	} else if(context.isPointInPath(bigRect, e.pageX, e.pageY)){
		startRemove = true;
	    // запомнить координаты, с которых начат перенос объекта
		//downX = e.pageX;
		//downY = e.pageY;
	} 
	downX = e.pageX;
	downY = e.pageY;
}

document.onmousemove = function(e) {
	if(shiftLath == true){
		console.log("success");
		let x = (downX - e.pageX);
		let y = (downY - e.pageY);
		drawRequestFrame(x);
	} else if(startRemove == true){
		if(Math.abs(downX - e.pageX) > 1 || Math.abs(downY - e.pageY)>1) {
			clearCanvas2();
			let x = startRectCordX-(downX - e.pageX);
			let y = startRectCordY-(downY - e.pageY);
			//if((x >= 0 && x <= canvas.width)&& (y >= 0 && y<= canvas.height)) {
				DrawRoundRectandleWithShadow(x,y,300, 300, 30);
				drawFirstSmallRect(30, 15, shiftFirstRect);
				drawSecondSmallRect(30, 15, shiftSecondRect);
		}
	} else if(startShiftSmallRect == true){
		if(e.pageX > decartRectMass[0].getX()+radDes*2 && e.pageX < decartRectMass[2].getX()-radDes){
			clearCanvas2();
			let x = (downX - e.pageX);
			let y = (downY - e.pageY);
			DrawRoundRectandleWithShadow(startRectCordX, startRectCordY ,300, 300, 30);
			drawFirstSmallRect(30, 15, shiftFirstRect+x);
			drawSecondSmallRect(30, 15, shiftSecondRect);
		} else {
			startShiftSmallRect = false;
		}
	} else if(startShiftSmallRect2 == true){
		if(e.pageX < decartRectMass[1].getX()-radDes && e.pageX > decartRectMass[3].getX()+radDes*2){
			clearCanvas2();
			let x = (downX - e.pageX);
			let y = (downY - e.pageY);
			DrawRoundRectandleWithShadow(startRectCordX, startRectCordY ,300, 300, 30);
			drawFirstSmallRect(30, 15, shiftFirstRect);
			drawSecondSmallRect(30, 15, shiftSecondRect-x);
		} else {
			startShiftSmallRect = false;
		}
	}
}

document.onmouseup = function(e) {
	if(startRemove == true){
		startRectCordX -= (downX - e.pageX);
		startRectCordY -= (downY - e.pageY);
		startRemove = false;
	} else if(startShiftSmallRect == true){
		shiftFirstRect += (downX - e.pageX);
		startShiftSmallRect = false;
	} else if(startShiftSmallRect2 == true){
		shiftSecondRect -= (downX - e.pageX);
		startShiftSmallRect2 = false;
	} else if(startShiftSmallRect_1_2){
		startShiftSmallRect_1_2 = false;
	} else if(startShiftSmallRect_2_1){
		startShiftSmallRect_2_1 = false;
	} else if(shiftLath){
		shiftLath = false;
	}
}

function DrawElips(a, b, d, degX, degY){
	start = true;
	var y;
	var x;
	context.beginPath();
	context.moveTo(centerX - a, centerY);
	for(var i = -300; i < 300; i+=1){
		y = (d - (i**degX / a**degX)*(b**degY))**(1/degY);
			context.lineTo(i + centerX, y + centerY);
	}
	for(var i = -300; i < 300; i+=1){
		y = (d - (i**degX / a**degX)*(b**degY))**(1/degY);
			context.lineTo(centerX - i, centerY - y);
	}
	context.strokeStyle='red';
	context.fillStyle = 'red'
	context.fill();
	context.stroke();
	context.closePath();
}

function Draw3DArc(){
	context.shadowOffsetX = 10;
    context.shadowOffsetY = 15;
    context.shadowBlur = 10;
    context.shadowColor = '#0F0';
    var gradient = context.createRadialGradient(60, 60, 15, 75, 75, 75);
    gradient.addColorStop(0.0, '#0F0');
    gradient.addColorStop(1.0, '#0DA805');

    context.fillStyle = gradient;

    context.beginPath();
    context.arc(75, 75, 75, 0, Math.PI * 2, false);
    context.fill();
    context.closePath();
}

function drawRectWithShadow() {
	var x1Pos = 25;
	var x2Pos = 200;
	var yPos = 10;
	var length = 150; 
	var height = 50;
	
	// первый прямоугольник с тенью
	context.shadowOffsetX = 4;
	context.shadowOffsetY = 4;
	context.shadowBlur = 3;
	context.fillStyle = "deeppink";
	context.shadowColor = "gray";
	context.fillRect (x1Pos, yPos, length, height);
	
	// второй прямоугольник с тенью
	context.shadowOffsetX = 12;
	context.shadowOffsetY = 12;
	context.shadowBlur = 4;
	context.strokeStyle = "aqua";
	context.shadowColor = "lightgreen";
	context.lineWidth = 8;
	context.strokeRect (x2Pos, yPos, length, height);
}