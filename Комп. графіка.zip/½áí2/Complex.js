class Complex {
	constructor(real,im) {
	  if (isNaN(real) || isNaN(im)) // Убедиться, что аргументы - числа.
		throw new TypeError("Error"); // Иначе возбудить исключение,
	  this.r = real;         // Вещественная часть числа,
	  this.imagin = im;    // Мнимая часть числа.
	}
	
	getReal(){ return this.r; }
	setReal(real) { this.r = real; }
	getImaginary() { return this.imagin; }
	setImaginary(im) { this.imagin = im; }
	
	mod() {
		return Math.sqrt(this.r*this.r + this.imagin*this.imagin);
	}
	// Возвращает комплексное число с противоположным знаком.
	neg() {
		return new Complex(-this.r, -this.imagin);
	}
	// Преобразует объект Complex в строку в понятном формате.
	toString() {
		return "{ " + this.r + ", " + this.imagin + "i }";
	}
	// Проверяет равенство данного комплексного числа с заданным.
	equals(that) {
	return that != null &&                  // должно быть определено, не равно null
	that.constructor === Complex &&         // и быть экземпляром Complex
	this.r === that.r && this.imagin === that.imagin; // и иметь те же значения.
	}
}
//сложение комплексных чисел
function add(a, b) {
	return (new Complex(a.getReal() + b.getReal(), a.getImaginary() + b.getImaginary()));
}
//умножение
function mul(a,b) {
	return new Complex(a.getReal() * b.getReal() - a.getImaginary() * b.getImaginary(), a.getReal() * b.getImaginary() + a.getImaginary() * b.getReal());
}
//деление
function div(a,b) {
	let d = b.getReal()^2 + b.getImaginary()^2;
	return new Complex((a.getReal()*b.getReal() + a.getImaginary()*b.getImaginary())/d, (b.getReal()*a.getImaginary() - a.getReal()*b.getImaginary())/d)
}