class DecartCord {
	constructor(X,Y){
		this.x = X;
		this.y = Y;
	}

	getX(){ return this.x; }
	getY(){ return this.y; }
	setX(X) {
		this.x = X; 
	}
	setY(Y) {
		this.y = Y;
	}

	toString() {
		return "{ " + this.x + ", " + this.y + " }";
	}
}