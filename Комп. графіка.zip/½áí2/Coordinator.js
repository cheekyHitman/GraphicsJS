'use strict';
var canv = document.getElementById('MyCanvas1');
 console.log(canv)
var ctx = canv.getContext('2d');

canv.width = 1200
canv.height = 800

var step = 40;
var width = canv.width;
var height = canv.height;
var start = 0;

var centerY = height/2;
var centerX = width/2;

function DrawCordinator(){
	ctx.beginPath();
	ctx.moveTo(0, centerY);
	ctx.lineTo(width, centerY);
	ctx.moveTo(centerX, 0);
	ctx.lineTo(centerX, height);
	ctx.strokeStyle='red';
	ctx.lineWidth=1;
	ctx.stroke();
	ctx.closePath();
	
	var tShiftLR = 5;
	var tShiftUD = -3;
	
	ctx.beginPath();
	for (var i = centerX; i <= width; i = i + step)
	{
		ctx.moveTo(i, start);
		ctx.lineTo(i, height);
		ctx.fillText((i-centerX)/step, i+tShiftLR, centerY+tShiftUD);
	}
	
	for (var i = centerY; i <= height; i = i + step)
	{
		ctx.moveTo(start, i);
		ctx.lineTo(width, i);
		if(i-centerY > 0){ ctx.fillText('-'+(i-centerY)/step, centerX+tShiftLR, i+tShiftUD); }
	}
	
	for (var i = centerX; i >= 0; i = i - step)
	{
		ctx.moveTo(i, start);
		ctx.lineTo(i, height);
		if(i+centerX != 2*i) { ctx.fillText((i-centerX)/step, i+tShiftLR, centerY+tShiftUD); }
	}
	
	for (var i = centerY; i >= 0; i = i - step)
	{
		ctx.moveTo(start, i);
		ctx.lineTo(width, i);
		if(i+centerX != 2*i) { ctx.fillText((-(i-centerY))/step, centerX+tShiftLR, i+tShiftUD); }
	}

	ctx.strokeStyle='black';
	ctx.lineWidth=1;
	ctx.stroke();
}

function CleanCanvas(){
	ctx.clearRect(0,0,canv.width, canv.height)
}