var x = 0;
var y = 0;
var z = step;
var cX = centerX;
var shLR = 0;

//start working with functions
function drawFunction(Y){
	z = step;
	shLR += shiftLR;

	let start = true;
	ctx.beginPath();
	for(i = -(cX + shLR)/z; i < (cX-shLR)/z; i+=1/(step**2)){
		x = i;
		y = eval(Y);

		if(start == true){
			ctx.moveTo(centerX+x*z, centerY-y*z);
			start = false;
		}
		ctx.lineTo(centerX+x*z, centerY-y*z);
	}
	ctx.strokeStyle='blue';
	ctx.lineWidth=1;
	ctx.stroke();
}